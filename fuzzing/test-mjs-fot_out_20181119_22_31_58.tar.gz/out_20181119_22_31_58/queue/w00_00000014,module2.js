let o = {
  a: 1,
  foo: ffi('int foo(int)'),
};
